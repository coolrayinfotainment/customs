#!/system/bin/sh
chmod +x /mnt/udisk2/done.sh

SCRIPT_PATH="/mnt/udisk2/done.sh"

. "$SCRIPT_PATH"